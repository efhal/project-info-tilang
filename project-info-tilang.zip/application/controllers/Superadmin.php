<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Superadmin extends CI_Controller
{		
	public function view_index(){
        echo __METHOD__;
    }
    public function proses_index(){
        echo __METHOD__;
    }
}