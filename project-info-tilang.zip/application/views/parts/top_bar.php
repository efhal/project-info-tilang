 <!-- Topbar Start -->
 <div class="navbar-custom bg-white">
     <div class="container-fluid">
         <ul class="list-unstyled topnav-menu float-right mb-0">

             <li class="d-none d-lg-block______">
                 <form class="app-search">
                     <div class="app-search-box dropdown">
                         <div class="input-group">
                             <input type="search" class="form-control" placeholder="Search..." id="top-search">
                             <div class="input-group-append">
                                 <button class="btn" type="submit">
                                     <i class="fe-search"></i>
                                 </button>
                             </div>
                         </div>
                         <div class="dropdown-menu dropdown-lg" id="search-dropdown">
                             <!-- item-->
                             <div class="dropdown-header noti-title">
                                 <h5 class="text-overflow mb-2">Found 22 results</h5>
                             </div>

                             <!-- item-->
                             <a href="javascript:void(0);" class="dropdown-item notify-item">
                                 <i class="fe-home mr-1"></i>
                                 <span>Analytics Report</span>
                             </a>

                             <!-- item-->
                             <a href="javascript:void(0);" class="dropdown-item notify-item">
                                 <i class="fe-aperture mr-1"></i>
                                 <span>How can I help you?</span>
                             </a>

                             <!-- item-->
                             <a href="javascript:void(0);" class="dropdown-item notify-item">
                                 <i class="fe-settings mr-1"></i>
                                 <span>User profile settings</span>
                             </a>

                             <!-- item-->
                             <div class="dropdown-header noti-title">
                                 <h6 class="text-overflow mb-2 text-uppercase">Users</h6>
                             </div>

                             <div class="notification-list">
                                 <!-- item-->
                                 <a href="javascript:void(0);" class="dropdown-item notify-item">
                                     <div class="media">
                                         <img class="d-flex mr-2 rounded-circle" src="<?= site_url() ?>assets/images/users/user-2.jpg" alt="Generic placeholder image" height="32">
                                         <div class="media-body">
                                             <h5 class="m-0 font-14">Erwin E. Brown</h5>
                                             <span class="font-12 mb-0">UI Designer</span>
                                         </div>
                                     </div>
                                 </a>

                                 <!-- item-->
                                 <a href="javascript:void(0);" class="dropdown-item notify-item">
                                     <div class="media">
                                         <img class="d-flex mr-2 rounded-circle" src="<?= site_url() ?>assets/images/users/user-5.jpg" alt="Generic placeholder image" height="32">
                                         <div class="media-body">
                                             <h5 class="m-0 font-14">Jacob Deo</h5>
                                             <span class="font-12 mb-0">Developer</span>
                                         </div>
                                     </div>
                                 </a>
                             </div>

                         </div>
                     </div>
                 </form>
             </li>

             <li class="dropdown d-inline-block__________ d-lg-none d-none">
                 <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                     <i class="fe-search noti-icon"></i>
                 </a>
                 <div class="dropdown-menu dropdown-lg dropdown-menu-right p-0">
                     <form class="p-3">
                         <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient's username">
                     </form>
                 </div>
             </li>

             <li class="dropdown d-none d-lg-inline-block__________">
                 <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="fullscreen" href="#">
                     <i class="fe-maximize noti-icon"></i>
                 </a>
             </li>

             <li class="dropdown d-none d-lg-inline-block__________ topbar-dropdown">
                 <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                     <i class="fe-grid noti-icon"></i>
                 </a>
                 <div class="dropdown-menu dropdown-lg dropdown-menu-right">

                     <div class="p-lg-1">
                         <div class="row no-gutters">
                             <div class="col">
                                 <a class="dropdown-icon-item" href="#">
                                     <img src="<?= site_url() ?>assets/images/brands/slack.png" alt="slack">
                                     <span>Slack</span>
                                 </a>
                             </div>
                             <div class="col">
                                 <a class="dropdown-icon-item" href="#">
                                     <img src="<?= site_url() ?>assets/images/brands/github.png" alt="Github">
                                     <span>GitHub</span>
                                 </a>
                             </div>
                             <div class="col">
                                 <a class="dropdown-icon-item" href="#">
                                     <img src="<?= site_url() ?>assets/images/brands/dribbble.png" alt="dribbble">
                                     <span>Dribbble</span>
                                 </a>
                             </div>
                         </div>

                         <div class="row no-gutters">
                             <div class="col">
                                 <a class="dropdown-icon-item" href="#">
                                     <img src="<?= site_url() ?>assets/images/brands/bitbucket.png" alt="bitbucket">
                                     <span>Bitbucket</span>
                                 </a>
                             </div>
                             <div class="col">
                                 <a class="dropdown-icon-item" href="#">
                                     <img src="<?= site_url() ?>assets/images/brands/dropbox.png" alt="dropbox">
                                     <span>Dropbox</span>
                                 </a>
                             </div>
                             <div class="col">
                                 <a class="dropdown-icon-item" href="#">
                                     <img src="<?= site_url() ?>assets/images/brands/g-suite.png" alt="G Suite">
                                     <span>G Suite</span>
                                 </a>
                             </div>

                         </div>
                     </div>

                 </div>
             </li>

             <li class="dropdown d-none d-lg-inline-block__________ topbar-dropdown">
                 <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                     <img src="<?= site_url() ?>assets/images/flags/us.jpg" alt="user-image" height="16">
                 </a>
                 <div class="dropdown-menu dropdown-menu-right">

                     <!-- item-->
                     <a href="javascript:void(0);" class="dropdown-item">
                         <img src="<?= site_url() ?>assets/images/flags/germany.jpg" alt="user-image" class="mr-1" height="12"> <span class="align-middle">German</span>
                     </a>

                     <!-- item-->
                     <a href="javascript:void(0);" class="dropdown-item">
                         <img src="<?= site_url() ?>assets/images/flags/italy.jpg" alt="user-image" class="mr-1" height="12"> <span class="align-middle">Italian</span>
                     </a>

                     <!-- item-->
                     <a href="javascript:void(0);" class="dropdown-item">
                         <img src="<?= site_url() ?>assets/images/flags/spain.jpg" alt="user-image" class="mr-1" height="12"> <span class="align-middle">Spanish</span>
                     </a>

                     <!-- item-->
                     <a href="javascript:void(0);" class="dropdown-item">
                         <img src="<?= site_url() ?>assets/images/flags/russia.jpg" alt="user-image" class="mr-1" height="12"> <span class="align-middle">Russian</span>
                     </a>

                 </div>
             </li>

             <li class="dropdown notification-list topbar-dropdown">
                 <a class="nav-link dropdown-toggle waves-effect waves-light text-dark" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                     <i class="fe-bell noti-icon"></i>
                     <span class="badge badge-danger rounded-circle noti-icon-badge d-none">9</span>
                 </a>
                 <div class="dropdown-menu dropdown-menu-right dropdown-lg">

                     <!-- item-->
                     <div class="dropdown-item noti-title">
                         <h5 class="m-0">
                             <span class="float-right">
                                 <a href="" class="text-dark">
                                     <small>Clear All</small>
                                 </a>
                             </span>Notification
                         </h5>
                     </div>

                     <div class="noti-scroll" data-simplebar>


                         <!-- item-->

                         <!-- item-->
                         <a href="javascript:void(0);" class="dropdown-item notify-item d-none">
                             <div class="notify-icon bg-warning">
                                 <i class="mdi mdi-account-plus"></i>
                             </div>
                             <p class="notify-details">New user registered.
                                 <small class="text-muted">5 hours ago</small>
                             </p>
                         </a>

                     </div>

                     <!-- All-->
                     <a href="javascript:void(0);" class="dropdown-item text-center text-primary notify-item notify-all">
                         View all
                         <i class="fe-arrow-right"></i>
                     </a>

                 </div>
             </li>

             <li class="dropdown notification-list topbar-dropdown">
                 <a class="nav-link dropdown-toggle mr-0 waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                     <span class="pro-user-name ml-1 text-dark">
                         <?= $data_session->nama_lengkap ?> <i class="mdi mdi-chevron-down"></i>
                     </span>
                 </a>
                 <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                     <!-- item-->
                     <div class="dropdown-header noti-title">
                         <h6 class="text-overflow m-0">Welcome <span class="text-primary"> <?= $data_session->nama_lengkap ?></span> !</h6>
                     </div>

                     <!-- item-->
                     <a href="<?= site_url($data_session->akronim . '/pengaturan') ?>" class="dropdown-item notify-item">
                         <i class="fe-user"></i>
                         <span>My Account</span>
                     </a>

                     <div class="dropdown-divider"></div>

                     <!-- item-->
                     <a href="<?= site_url('logout') ?>" class="dropdown-item notify-item">
                         <i class="mdi mdi-power mdi-24px"></i>
                         <span>Logout</span>
                     </a>

                 </div>
             </li>

             <li class="dropdown notification-list">
                 <a href="<?= site_url('logout') ?>" class="nav-link right-bar-toggle waves-effect waves-light text-dark">
                     <i class="mdi mdi-logout mdi-24px"></i>
                 </a>
             </li>

         </ul>

         <!-- LOGO -->
         <div class="logo-box">
             <a href="<?= site_url($data_session->akronim . '/ph') ?>" class="logo logo-dark text-center">
                 <span class="logo-sm">
                     <img src="<?= site_url() ?>assets/images/logo-sm.png" alt="" height="42">
                     <!-- <span class="logo-lg-text-light">UBold</span> -->
                 </span>
                 <span class="logo-lg">
                     <img src="<?= site_url() ?>assets/images/logo-dark.png" alt="" height="20">
                     <!-- <span class="logo-lg-text-light">U</span> -->
                 </span>
             </a>

             <a href="<?= site_url($data_session->akronim . '/ph') ?>" class="logo logo-light text-center">
                 <span class="logo-sm">
                     <img src="<?= site_url() ?>assets/images/logo-sm.png" alt="" height="32">
                 </span>
                 <span class="logo-lg">
                     <img src="<?= site_url() ?>assets/images/logo-light.png" alt="" height="20">
                 </span>
             </a>
         </div>

         <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
             <li>
                 <button class="button-menu-mobile waves-effect waves-light text-dark">
                     <i class="fe-menu"></i>
                 </button>
             </li>

             <li>
                 <!-- Mobile menu toggle (Horizontal Layout)-->
                 <a class="navbar-toggle nav-link" data-toggle="collapse" data-target="#topnav-menu-content">
                     <div class="lines">
                         <span></span>
                         <span></span>
                         <span></span>
                     </div>
                 </a>
                 <!-- End mobile menu toggle-->
             </li>

             <li class="dropdown d-none d-xl-block______">
                 <a class="nav-link dropdown-toggle waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                     Create New
                     <i class="mdi mdi-chevron-down"></i>
                 </a>
                 <div class="dropdown-menu">
                     <!-- item-->
                     <a href="javascript:void(0);" class="dropdown-item">
                         <i class="fe-briefcase mr-1"></i>
                         <span>New Projects</span>
                     </a>

                     <!-- item-->
                     <a href="javascript:void(0);" class="dropdown-item">
                         <i class="fe-user mr-1"></i>
                         <span>Create Users</span>
                     </a>

                     <!-- item-->
                     <a href="javascript:void(0);" class="dropdown-item">
                         <i class="fe-bar-chart-line- mr-1"></i>
                         <span>Revenue Report</span>
                     </a>

                     <!-- item-->
                     <a href="javascript:void(0);" class="dropdown-item">
                         <i class="fe-settings mr-1"></i>
                         <span>Settings</span>
                     </a>

                     <div class="dropdown-divider"></div>

                     <!-- item-->
                     <a href="javascript:void(0);" class="dropdown-item">
                         <i class="fe-headphones mr-1"></i>
                         <span>Help & Support</span>
                     </a>

                 </div>
             </li>

             <li class="dropdown dropdown-mega d-none d-xl-block______">
                 <a class="nav-link dropdown-toggle waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                     Mega Menu
                     <i class="mdi mdi-chevron-down"></i>
                 </a>
                 <div class="dropdown-menu dropdown-megamenu">
                     <div class="row">
                         <div class="col-sm-8">

                             <div class="row">
                                 <div class="col-md-4">
                                     <h5 class="text-dark mt-0">UI Components</h5>
                                     <ul class="list-unstyled megamenu-list">
                                         <li>
                                             <a href="javascript:void(0);">Widgets</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Nestable List</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Range Sliders</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Masonry Items</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Sweet Alerts</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Treeview Page</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Tour Page</a>
                                         </li>
                                     </ul>
                                 </div>

                                 <div class="col-md-4">
                                     <h5 class="text-dark mt-0">Applications</h5>
                                     <ul class="list-unstyled megamenu-list">
                                         <li>
                                             <a href="javascript:void(0);">eCommerce Pages</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">CRM Pages</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Email</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Calendar</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Team Contacts</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Task Board</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Email Templates</a>
                                         </li>
                                     </ul>
                                 </div>

                                 <div class="col-md-4">
                                     <h5 class="text-dark mt-0">Extra Pages</h5>
                                     <ul class="list-unstyled megamenu-list">
                                         <li>
                                             <a href="javascript:void(0);">Left Sidebar with User</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Menu Collapsed</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Small Left Sidebar</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">New Header Style</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Search Result</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Gallery Pages</a>
                                         </li>
                                         <li>
                                             <a href="javascript:void(0);">Maintenance & Coming Soon</a>
                                         </li>
                                     </ul>
                                 </div>
                             </div>
                         </div>
                         <div class="col-sm-4">
                             <div class="text-center mt-3">
                                 <h3 class="text-dark">Special Discount Sale!</h3>
                                 <h4>Save up to 70% off.</h4>
                                 <button class="btn btn-primary btn-rounded mt-3">Download Now</button>
                             </div>
                         </div>
                     </div>

                 </div>
             </li>
         </ul>
         <div class="clearfix"></div>
     </div>
 </div>
 <!-- end Topbar -->