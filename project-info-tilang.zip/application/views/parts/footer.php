          <footer class="footer bg-white">
              <div class="container-fluid">
                  <div class="row">
                      <div class="col-md-6">
                          2020 - <script>
                              document.write(new Date().getFullYear())
                          </script> &copy; UBold theme by <a href=""><?= NAMA_APLIKASI ?></a>
                      </div>
                      <div class="col-md-6">
                          <div class="text-md-right footer-links d-none d-sm-block">
                              <a href="javascript:void(0);">Tentang</a>
                              <a href="javascript:void(0);">Ketentuan Penggunaan</a>
                              <a href="javascript:void(0);">Kontak Kami</a>
                          </div>
                      </div>
                  </div>
              </div>
          </footer>