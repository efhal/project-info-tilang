  <!-- Vendor js -->
        <script src="<?= site_url()?>assets/js/vendor.min.js"></script>
        <!-- App js -->
        <script src="<?= site_url()?>assets/js/app.min.js"></script>