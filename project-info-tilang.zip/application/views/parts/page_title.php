    					<div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right d-none">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">UBold</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Layouts</a></li>
                                            <li class="breadcrumb-item active">Two Tone Menu</li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title"><?= $page_title?></h4>
                                </div>
                            </div>
                        </div>     