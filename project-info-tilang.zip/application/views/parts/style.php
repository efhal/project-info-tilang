		<meta charset="utf-8" />
  
		<!-- App css -->
		<link href="<?= site_url()?>assets/css/bootstrap-purple.min.css" rel="stylesheet" type="text/css" id="bs-default-stylesheet" />
		<link href="<?= site_url()?>assets/css/app-purple.min.css" rel="stylesheet" type="text/css" id="app-default-stylesheet" />

		<link href="<?= site_url()?>assets/css/bootstrap-purple-dark.min.css" rel="stylesheet" type="text/css" id="bs-dark-stylesheet" disabled />
		<link href="<?= site_url()?>assets/css/app-purple-dark.min.css" rel="stylesheet" type="text/css" id="app-dark-stylesheet"  disabled />

		<!-- icons -->
		<link href="<?= site_url()?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />